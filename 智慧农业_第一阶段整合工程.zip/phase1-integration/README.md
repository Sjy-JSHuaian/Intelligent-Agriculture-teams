# 智慧农业三模块协同原型 · 第一阶段

本工程把指定仓库的路径规划、图像分析、历史气象筛查核心代码接成一个可运行的协同流程，作为大创项目第一阶段的软件集成成果。

**已经实现：初始巡检仿真 → RGB图像分析 → 历史气象与地块证据融合 → 复查任务 → 路径再规划。**

当前验证的是软件协同和数据契约。图像、地块、地形均为明确标记的合成联调数据；天气使用仓库中2021—2025年加榜区域历史数据重新计算。语义分割权重没有随仓库提交，因此首版不运行SegFormer，也不声称完成预测模型训练或真实无人机验证。

## 先看哪些文件

- `docs/五分支审查与第一阶段整合方案.md`：分支现状、阻塞问题、整合架构、后续大创任务。
- `docs/接口契约.md`：三个模块如何传递地块、图像、时间和坐标。
- `validation/验收结果.md`：本次运行结果、测试证据和限制。
- `runs/demo/result.json`：已生成的完整联调结果。
- `docs/branch_inventory.json`、`docs/source_manifest.json`：五分支提交号、全部文件清单和移植源码来源。

## 安装

推荐Python 3.11；无需GPU、PyTorch、GDAL、模型下载或数据库。命令均在本目录执行。

```powershell
python --version
python -m venv .venv
.venv\Scripts\python -m pip install -r requirements-lock.txt
```

`requirements-lock.txt`记录本次Windows / Python 3.11干净环境实际安装的精确版本，包含测试依赖。其他平台可使用`requirements-dev.txt`重新解析兼容版本。仅运行服务可安装`requirements.txt`。

## 一键联调

```powershell
.venv\Scripts\python -m agriculture demo --output runs/demo
```

默认回放日期`2025-06-24`。输出54张合成拍摄图，每块地选最新一张分析；正常地块不因区域天气信号而自动变成异常地块。两个异常候选地块进入复查队列。重新规划不是修改旧航线的飞行中状态，而是生成下一次复查任务。

可改变历史日期，但必须在仓库天气覆盖期间内：

```powershell
.venv\Scripts\python -m agriculture demo --date 2025-07-01 --output runs/another_day
```

结果文件：

| 文件 | 内容 |
|---|---|
| `runs/demo/inspection.json` | 巡检拍照索引、拍摄时间、覆盖统计 |
| `runs/demo/images/` | 合成RGB图像，不能作为模型精度验证样本 |
| `runs/demo/fusion_request.json` | 实际图像计算结果与地块元数据组成的融合输入 |
| `runs/demo/result.json` | 图像结果、天气线索、隔离记录、复查任务和前后航线 |

## 统一API

```powershell
.venv\Scripts\python -m uvicorn agriculture.api:app --host 127.0.0.1 --port 8010
```

浏览器打开 `http://127.0.0.1:8010/docs`。无需启动原来三个独立服务。

| 方法 | 地址 | 作用 |
|---|---|---|
| GET | `/health` | 功能与模型可用状态 |
| POST | `/image/analyze` | 上传PNG/JPEG RGB，返回植被指数和异常候选比例 |
| POST | `/image/segment` | 明确返回503：分割权重与完整预处理未接入 |
| GET | `/weather/risk?as_of_date=2025-06-24` | 重算得到的当日五类气象筛查记录 |
| POST | `/integration/fuse` | 融合天气、图像、地块证据；真实数据只进行证据审查 |
| POST | `/planning/from-evidence` | 仅对匹配的合成联调场景生成复查航线 |
| POST | `/demo/run` | `{"demo_mode":true,"as_of_date":"2025-06-24"}`执行完整联调 |

API演示使用每次调用独立的临时目录，返回JSON但不保留图片。需要保留全部证据时使用CLI。请求中的`source_reference`是数据来源引用，不是HTTP下载地址。

也可在文件方式下重新融合，不启动服务：

```powershell
.venv\Scripts\python -m agriculture fuse runs/demo/fusion_request.json --output runs/fusion.json
```

## 测试与原场景回归

```powershell
.venv\Scripts\python -m pytest -q --basetemp=work/pytest
.venv\Scripts\python scripts/check_path_reference.py
```

原场景回归约需一分钟，独立使用元阳数据，不与加榜天气融合。两套完整场景均保留基线/改进算法。`scene_simple`在上游仓库缺少必需缓存，本工程没有伪造补全。

## 工程结构

```text
agriculture/
  image/             原图像分析函数 + 补建的RGB预处理 + 轻量服务
  weather/           原气象清洗、规则和融合函数 + 重算入口
  planning/          原路径规划与巡检核心代码，改为独立命名空间
  bridge.py          时间/地区/场景校验，任务适配与全航线检查
  demo_scene.py      加榜区域合成联调场景和可控图像纹理
  pipeline.py        完整编排流程和证据落盘
  api.py             统一FastAPI入口
data/weather/        原始整理后天气及来源说明
data/path_reference/ 两套完整元阳场景缓存及原结果
tests/               移植的图像测试与新增联调测试
docs/                审查、设计、接口、来源与上游文档快照
validation/          实测记录、JUnit、环境版本、场景回归结果
```

本交付是独立可运行的本地整合工程，没有推送或更改GitHub分支。建议先作为`develop`下的`phase1/`目录引入，通过验收后再统一仓库根目录，具体步骤见审查报告。
