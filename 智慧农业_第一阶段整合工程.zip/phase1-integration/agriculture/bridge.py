"""Explicit contracts between image, weather evidence, and simulation planning."""
import copy
from datetime import date
import numpy as np
from shapely.geometry import shape
from .weather.integration import fuse
from .weather.service import weather_bundle, daily_records
from .demo_scene import scene_plots
from .planning.planner.route import plan_mission


def fuse_evidence(payload):
    if not isinstance(payload, dict):
        raise ValueError('Request must be an object')
    if type(payload.get('demo_mode', False)) is not bool:
        raise ValueError('demo_mode must be a boolean')
    as_of = payload.get('as_of_date')
    if not isinstance(as_of, str):
        raise ValueError('as_of_date must be an ISO date')
    date.fromisoformat(as_of)
    cfg = weather_bundle()[0]
    daily = daily_records(as_of)
    if payload.get('site_id') != cfg['site_id']:
        raise ValueError('site_id must match the weather region')
    plots = payload.get('plots', {'type':'FeatureCollection','features':[]})
    if not isinstance(plots, dict) or not isinstance(plots.get('features'), list):
        raise ValueError('plots must be a FeatureCollection')
    for feature in plots['features']:
        if not isinstance(feature, dict) or not isinstance(feature.get('properties'), dict):
            raise ValueError('Invalid plot feature')
        if type(feature['properties'].get('is_synthetic', False)) is not bool:
            raise ValueError('is_synthetic must be a boolean')
    observations = payload.get('image_observations', [])
    if not isinstance(observations, list):
        raise ValueError('image_observations must be a list')
    for item in observations:
        if not isinstance(item, dict) or not isinstance(item.get('metadata'), dict):
            raise ValueError('Each observation needs metadata')
        if type(item['metadata'].get('is_synthetic', False)) is not bool:
            raise ValueError('is_synthetic must be a boolean')
        if not isinstance(item.get('response'), dict):
            raise ValueError('Each observation needs an image response')
    if 'a_observations' in payload:
        raise ValueError('Use image_observations; legacy A/B labels are not a public contract')
    plot_scenes = {f['properties'].get('plot_id'):f['properties'].get('scene_id')
                   for f in plots['features']}
    scene_quarantine, bound_observations = [], []
    for item in observations:
        metadata = item['metadata']
        expected_scene = plot_scenes.get(metadata.get('plot_id'))
        if metadata.get('scene_id') != expected_scene:
            scene_quarantine.append({'observation_id':metadata.get('observation_id'),
                                     'reason':'Image and plot scene_id mismatch'})
        else:
            bound_observations.append(item)
    upstream = {**payload, 'a_observations':bound_observations, 'plots':plots}
    result = fuse(upstream, daily, cfg)
    result['quarantined_observations'].extend(scene_quarantine)
    plot_by_id = {f['properties']['plot_id']:f['properties'] for f in plots['features']}
    for task in result['inspection_requests']:
        task['site_id'] = cfg['site_id']
        task['scene_id'] = plot_by_id[task['plot_id']].get('scene_id')
        task['execution_status'] = 'awaiting_planning_and_site_checks'
    result['schema_version'] = '1.0'
    result['site_id'] = cfg['site_id']
    return result


def check_route(scene, trajectory):
    """Check all legs, including capture lanes and snapped A* connectors.

    Original collision_count covers transit paths only. This is a sampled grid
    simulation check, not a certified continuous collision detector.
    """
    blocked = scene.blocked()
    hits = 0
    points = trajectory['waypoints']
    for first, second in zip(points, points[1:]):
        a = np.array([first['x'],first['y']])
        b = np.array([second['x'],second['y']])
        if not np.isfinite([*a,*b,first['z'],second['z']]).all():
            raise ValueError('Non-finite waypoint')
        samples = max(2,int(np.ceil(np.linalg.norm(b-a) / .5))+1)
        for xy in np.linspace(a,b,samples):
            r,c = scene.xy_to_rc(xy)
            if not scene.in_bounds(r,c) or blocked[r,c]:
                hits += 1
    battery_ok = trajectory['metrics']['battery_reserve_ok']
    upstream_hits = trajectory['metrics'].get('collision_count',0)
    upstream_violation = trajectory['metrics'].get('safety_violation_m',0)
    return {'scope':'all legs at <=0.5 m sampling on 5 m grid',
            'blocked_samples':hits,'battery_reserve_ok':battery_ok,
            'upstream_collision_count':upstream_hits,
            'upstream_safety_violation_m':upstream_violation,
            'passed':hits == 0 and battery_ok and upstream_hits == 0 and upstream_violation == 0,
            'flight_ready':False}


def plan_requests(scene, fusion):
    if not scene.meta.get('is_synthetic') or fusion['mode'] != 'synthetic_contract_demo':
        raise ValueError('Phase 1 route adapter accepts explicit simulation only; real scene binding is pending')
    if fusion.get('site_id') != scene.meta.get('site_id'):
        raise ValueError('Scene and evidence site mismatch')
    tasks = fusion['inspection_requests']
    if not tasks:
        return {'status':'no_inspection_requested','trajectory':None,'flight_ready':False}
    expected = {f['properties']['plot_id']:f['geometry'] for f in scene_plots(scene)['features']}
    selected = []
    seen = set()
    for task in tasks:
        pid = task['plot_id']
        if task.get('scene_id') != scene.scene_id or pid not in scene.field_by_id or pid in seen:
            raise ValueError('Unknown, duplicate or wrong-scene plot_id')
        seen.add(pid)
        if task.get('geometry_crs') != 'EPSG:4326' or not shape(task['geometry']).equals_exact(shape(expected[pid]),1e-8):
            raise ValueError('Task geometry differs from the bound simulation field')
        if task.get('priority') not in {'P1','P2'} or task.get('is_synthetic_demo') is not True:
            raise ValueError('Invalid priority or simulation provenance')
        field = copy.deepcopy(scene.field_by_id[pid])
        field.risk, field.risk_level, field.priority = (1.,'high',3) if task['priority']=='P1' else (.5,'medium',2)
        selected.append(field)
    trajectory = plan_mission(scene, method='improved', field_subset=selected)
    trajectory['priority_semantics'] = 'risk fields encode inspection ordering, not probability'
    trajectory['site_id'] = scene.meta['site_id']
    trajectory['is_synthetic'] = True
    trajectory['flight_ready'] = False
    validation = check_route(scene,trajectory)
    return {'status':'simulation_validated' if validation['passed'] else 'simulation_rejected',
            'trajectory':trajectory,'validation':validation,'flight_ready':False}
