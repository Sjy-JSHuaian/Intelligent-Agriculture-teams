"""One local API; no heavyweight model import is required for RGB analysis."""
from datetime import date
from pathlib import Path
from tempfile import TemporaryDirectory
from fastapi import FastAPI, File, HTTPException, UploadFile
from pydantic import BaseModel, ConfigDict, StrictBool
from .image.service import decode_image, analyze_image, MAX_BYTES
from .weather.service import daily_records
from .bridge import fuse_evidence, plan_requests
from .demo_scene import make_scene
from .pipeline import run_demo

app = FastAPI(title='智慧农业三模块协同原型',version='0.1.0',
              description='历史气象回放 + RGB异常候选 + 巡检路径仿真。非实时预报，非飞控服务。')


class DemoRequest(BaseModel):
    model_config = ConfigDict(extra='forbid')
    demo_mode: StrictBool
    as_of_date: date = date(2025,6,24)


def bad_input(exc):
    return HTTPException(422,detail={'success':False,'message':str(exc)})


@app.get('/health')
def health():
    return {'success':True,'data':{'version':'0.1.0','image':'rgb_rules',
            'weather':'historical_rules','planning':'simulation',
            'segmentation_available':False,'is_forecast':False,'flight_ready':False}}


@app.post('/image/analyze')
async def image_analyze(file: UploadFile = File(...)):
    try:
        return analyze_image(decode_image(await file.read(MAX_BYTES+1)))
    except ValueError as exc:
        raise bad_input(exc) from exc


@app.post('/image/segment',status_code=503)
def segment_unavailable():
    return {'success':False,'message':'Trained weights and complete upstream preprocessing are absent; segmentation is not connected'}


@app.get('/weather/risk')
def weather_risk(as_of_date: date):
    try:
        return {'success':True,'data':daily_records(as_of_date.isoformat())}
    except ValueError as exc:
        raise HTTPException(404,str(exc)) from exc


@app.post('/integration/fuse')
def fusion(payload: dict):
    try:
        return {'success':True,'data':fuse_evidence(payload)}
    except (ValueError,KeyError,TypeError,AttributeError) as exc:
        raise bad_input(exc) from exc


@app.post('/planning/from-evidence')
def planning(payload: dict):
    """Recompute fusion from evidence; never accept user-supplied risk scores as facts."""
    try:
        result = fuse_evidence(payload)
        return {'success':True,'data':plan_requests(make_scene(),result)}
    except (ValueError,KeyError,TypeError,AttributeError) as exc:
        raise bad_input(exc) from exc


@app.post('/demo/run')
def demo(payload: DemoRequest):
    if payload.demo_mode is not True:
        raise HTTPException(422,'demo_mode must explicitly be true')
    try:
        # Isolated directory per call avoids simultaneous requests overwriting runs.
        with TemporaryDirectory(prefix='agriculture-demo-') as directory:
            result = run_demo(Path(directory),payload.as_of_date.isoformat())
            return {'success':True,'data':{'summary':result['summary'],
                    'fusion':result['fusion'],'before':result['before'],'after':result['after'],
                    'artifacts_persisted':False,
                    'note':'Use the CLI to preserve images and evidence files'}}
    except ValueError as exc:
        raise bad_input(exc) from exc
