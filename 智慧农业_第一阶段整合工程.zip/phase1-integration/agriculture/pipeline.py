from datetime import datetime
from pathlib import Path
import hashlib
import json
import numpy as np
from PIL import Image
from .demo_scene import make_scene, scene_plots, write_demo_image, SITE_ID
from .image.service import analyze_image
from .planning.planner.route import plan_mission
from .planning.simulator.inspect import inspect_mission
from .bridge import fuse_evidence, plan_requests, check_route
from .weather.service import daily_records, weather_bundle


def write_json(path, value):
    Path(path).write_text(json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf-8')


def add_coverage(trajectory, inspection):
    trajectory['metrics']['coverage_pct'] = inspection['totals']['coverage_pct']
    trajectory['metrics']['coverage_pct_mean_field'] = inspection['totals']['mean_field_coverage_pct']


def run_demo(output, as_of='2025-06-24'):
    daily_records(as_of)
    output = Path(output)
    output.mkdir(parents=True,exist_ok=True)
    scene = make_scene()
    before = plan_mission(scene,'baseline')
    before.update({'site_id':SITE_ID,'is_synthetic':True,'flight_ready':False})
    before['priority_semantics'] = 'All fields initially have equal inspection priority'
    start = datetime.fromisoformat(as_of+'T08:00:00+08:00')
    inspection = inspect_mission(before,scene,out_dir=output,start=start,
                                 image_writer=write_demo_image)
    inspection['is_synthetic'] = True
    inspection['image_note'] = 'Controlled synthetic RGB textures; not field photographs or model validation data'
    add_coverage(before,inspection)
    latest = {}
    for capture in inspection['images']:
        latest[capture['field_id']] = capture
    observations = []
    for pid,capture in latest.items():
        image_path = output / capture['path']
        with Image.open(image_path) as image:
            rgb = np.array(image.convert('RGB'))
        response = analyze_image(rgb)
        metadata = {'observation_id':capture['image_id'], 'plot_id':pid,
                    'site_id':SITE_ID, 'scene_id':scene.scene_id,
                    'captured_at':capture['timestamp'], 'image_scope':'single_plot_crop',
                    'location_verified':True,'plot_association_verified':True,
                    'source_reference':capture['path'],
                    'image_sha256':hashlib.sha256(image_path.read_bytes()).hexdigest(),
                    'is_synthetic':True,
                    'verification_scope':'Synthetic fixture association only, NOT field verification'}
        observations.append({'metadata':metadata,'response':response})
    request = {'demo_mode':True,'site_id':SITE_ID,'as_of_date':as_of,
               'plots':scene_plots(scene),'image_observations':observations}
    fusion = fuse_evidence(request)
    after = plan_requests(scene,fusion)
    if after['trajectory'] is not None:
        after_inspect = inspect_mission(after['trajectory'],scene,generate_images=False,
                                       out_dir=output,start=start)
        add_coverage(after['trajectory'],after_inspect)
        after['coverage'] = after_inspect['totals']
    before_validation = check_route(scene,before)
    result = {
        'schema_version':'1.0', 'mode':'synthetic_end_to_end_demo',
        'as_of_date':as_of, 'site_id':SITE_ID,'scene_id':scene.scene_id,
        'provenance':{'weather':'Repository historical observations, recomputed with original rules',
                      'terrain':'Synthetic analytic surface', 'plots':'Synthetic polygons',
                      'images':'Synthetic RGB textures generated from field ID, independent of risk scores',
                      'validation_scope':'Software/data contract integration, NOT predictive accuracy'},
        'weather_quality':weather_bundle()[1],
        'before':{'trajectory':before,'validation':before_validation},
        'image_observations':observations,'fusion':fusion,'after':after,
        'summary':{'fields':len(scene.fields),'capture_images':len(inspection['images']),
                   'analyzed_images':len(observations),
                   'accepted_images':len(fusion['accepted_image_observations']),
                   'quarantined_images':len(fusion['quarantined_observations']),
                   'inspection_requests':len(fusion['inspection_requests']),
                   'before_order':before['route'],
                   'after_order':after['trajectory']['route'] if after['trajectory'] else [],
                   'is_forecast':False,'segmentation_available':False,'flight_ready':False},
    }
    write_json(output/'fusion_request.json',request)
    write_json(output/'inspection.json',inspection)
    write_json(output/'result.json',result)
    return result
