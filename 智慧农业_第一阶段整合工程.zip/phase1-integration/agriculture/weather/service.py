from functools import lru_cache
from pathlib import Path
from datetime import date
import json
from .weather import load_clean, indicators
from .rules import fit_thresholds, screen

DATA = Path(__file__).resolve().parents[2] / 'data/weather'


@lru_cache(maxsize=1)
def weather_bundle():
    cfg = json.loads((DATA / 'config.json').read_text(encoding='utf-8'))
    clean, quality = load_clean(DATA / 'weather_daily.csv')
    features = indicators(clean, cfg)
    thresholds = fit_thresholds(features, cfg)
    records = screen(features, thresholds, cfg)
    return cfg, quality, thresholds, records


def daily_records(as_of):
    date.fromisoformat(as_of)
    records = [r for r in weather_bundle()[3] if r['date'] == as_of]
    if not records:
        raise ValueError('No weather for date; available period is 2021-01-01..2025-12-31')
    return records
