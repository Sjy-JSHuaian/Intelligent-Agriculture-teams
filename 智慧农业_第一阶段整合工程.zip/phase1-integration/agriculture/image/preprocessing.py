"""Restored RGB primitives; upstream referenced an uncommitted datasets package.

These are new implementations of the documented formulas, not recovered training
preprocessing. Inputs are uint8 RGB or finite float RGB in [0, 1].
"""
import numpy as np


def to_float01(rgb):
    rgb = np.asarray(rgb)
    if rgb.ndim != 3 or rgb.shape[2] != 3 or 0 in rgb.shape:
        raise ValueError('Expected a nonempty HWC RGB image')
    if rgb.dtype == np.uint8:
        return rgb.astype(np.float32) / 255.0
    if not np.issubdtype(rgb.dtype, np.floating):
        raise ValueError('Use uint8 or floating RGB in [0, 1]')
    if not np.isfinite(rgb).all() or rgb.min() < 0 or rgb.max() > 1:
        raise ValueError('Floating RGB must be finite and in [0, 1]')
    return rgb.astype(np.float32)


def _channels(rgb):
    x = to_float01(rgb)
    return x[..., 0], x[..., 1], x[..., 2]


def _ratio(numerator, denominator):
    out = np.zeros_like(numerator, dtype=np.float32)
    np.divide(numerator, denominator, out=out, where=np.abs(denominator) > 1e-6)
    return np.clip(out, -1, 1)


def compute_exg(rgb):
    r, g, b = _channels(rgb)
    return 2 * g - r - b


def compute_gli(rgb):
    r, g, b = _channels(rgb)
    return _ratio(2 * g - r - b, 2 * g + r + b)


def compute_vari(rgb):
    r, g, b = _channels(rgb)
    return _ratio(g - r, g + r - b)


def compute_ndi(rgb):
    r, g, _ = _channels(rgb)
    return _ratio(g - r, g + r)


def compute_rgb_indices(rgb):
    return {'VARI': compute_vari(rgb), 'ExG': compute_exg(rgb),
            'GLI': compute_gli(rgb), 'NDI': compute_ndi(rgb)}
