from io import BytesIO
import numpy as np
from PIL import Image, UnidentifiedImageError
from .vegetation import analyze_vegetation, vegetation_fraction
from .anomaly import detect_low_vigor, detect_bare_land

MAX_BYTES = 20 * 1024 * 1024
MAX_PIXELS = 16_000_000


def decode_image(data):
    if not data or len(data) > MAX_BYTES:
        raise ValueError('Image must be nonempty and at most 20 MiB')
    try:
        with Image.open(BytesIO(data)) as image:
            if image.format not in {'PNG', 'JPEG'}:
                raise ValueError('Only PNG/JPEG RGB images are accepted')
            if image.width * image.height > MAX_PIXELS:
                raise ValueError('Image exceeds 16 million pixels')
            if image.mode != 'RGB':
                raise ValueError('Supply an explicit three-channel RGB image')
            return np.array(image)
    except (UnidentifiedImageError, OSError, Image.DecompressionBombError) as exc:
        raise ValueError('Cannot decode image') from exc


def analyze_image(rgb):
    vegetation = analyze_vegetation(rgb)
    low = detect_low_vigor(rgb)
    bare = detect_bare_land(rgb)
    return {
        'success': True,
        'data': {
            'width': int(rgb.shape[1]), 'height': int(rgb.shape[0]),
            'vegetation': {
                'vegetation_fraction_gli': vegetation['vegetation_fraction'],
                'vegetation_fraction_vari': vegetation_fraction(rgb, 'VARI'),
                'index_statistics': vegetation['index_statistics'],
                'note': 'RGB indices, not NDVI; thresholds require field calibration',
            },
            'anomaly': {'low_vigor_fraction': float(low.mean()),
                        'bare_land_fraction': float(bare.mean())},
            'segmentation': {'status': 'unavailable',
                             'reason': 'Upstream trained weights and datasets source are absent'},
        },
    }
