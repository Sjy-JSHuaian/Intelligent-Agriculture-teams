"""Small Jiabang contract fixture. ALL terrain, polygons and images are synthetic."""
import numpy as np
from PIL import Image
from pyproj import Transformer
from .planning.common.edt import distance_transform_edt
from .planning.simulator.scene import Scene, Field

SITE_ID = 'jiabang_initial_aoi'
SCENE_ID = 'jiabang_synthetic_v1'
CRS = 'EPSG:32649'


def make_scene():
    cell, n = 5., 40
    yy, xx = np.mgrid[:n, :n]
    x, y = (xx + .5) * cell, 200 - (yy + .5) * cell
    elevation = 1000 + .08 * y + .03 * x
    slope = np.full((n, n), np.degrees(np.arctan(np.hypot(.08, .03))))
    hard = (x > 90) & (x < 110) & (y > 85) & (y < 115)
    ids = np.zeros((n, n), dtype=np.int32)
    fields = []
    # T001 is normal; T002 and T003 have controlled synthetic low-greenness patches.
    for i, (left, bottom) in enumerate([(35, 35), (130, 40), (65, 140)], 1):
        polygon = np.array([[left,bottom],[left+35,bottom],
                            [left+35,bottom+30],[left,bottom+30]],dtype=float)
        mask = (x >= left) & (x < left+35) & (y >= bottom) & (y < bottom+30)
        ids[mask] = i
        fields.append(Field(f'T{i:03d}', polygon, 0., 'low', 1, 1050.,
                            polygon.mean(axis=0), float(elevation[mask].mean())))
    origin = Transformer.from_crs('EPSG:4326', CRS, always_xy=True).transform(108.586,25.602)
    meta = {'name': '加榜三地块合成联调场景（非实测）', 'complexity':'synthetic',
            'cell_m':cell, 'nx':n, 'ny':n, 'size_m':200., 'origin_xy':origin,
            'crs':CRS, 'site_id':SITE_ID, 'is_synthetic':True,
            'sources': {'terrain':'analytic plane, NOT a DEM survey',
                        'fields':'synthetic rectangles', 'obstacle':'synthetic rectangle'}}
    return Scene(SCENE_ID, meta, elevation, slope, np.zeros((n,n)), np.zeros((n,n)),
                 hard, np.zeros((n,n)), ids, distance_transform_edt(hard,cell), fields,
                 np.array([[0,0],[200,0],[200,200],[0,200]]), np.array([20.,20.]), origin)


def scene_plots(scene):
    transform = Transformer.from_crs(scene.meta['crs'], 'EPSG:4326', always_xy=True)
    features = []
    for field in scene.fields:
        ring = [list(transform.transform(*(p + scene.utm_origin))) for p in field.polygon]
        ring.append(ring[0])
        features.append({'type':'Feature', 'geometry':{'type':'Polygon','coordinates':[ring]},
                         'properties':{'plot_id':field.field_id, 'scene_id':scene.scene_id,
                            'site_id':SITE_ID, 'crs':'EPSG:4326', 'crs_verified':True,
                            'boundary_verified':True, 'is_synthetic':True,
                            'boundary_source':'Synthetic fixture; verified within simulation only'}})
    return {'type':'FeatureCollection', 'features':features}


def write_demo_image(path, field_id, risk, seed, stamp):
    """Controlled test texture, independent of planning risk to avoid feedback leakage."""
    image = np.empty((128,128,3),dtype=np.uint8)
    image[:] = [40,140,40]
    patch_width = {'T001':0, 'T002':24, 'T003':48}[field_id]
    image[:, :patch_width] = [120,90,50]
    path.parent.mkdir(parents=True,exist_ok=True)
    Image.fromarray(image).save(path,quality=100,subsampling=0)
