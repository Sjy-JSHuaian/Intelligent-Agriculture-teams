import argparse
import json
from pathlib import Path
from .pipeline import run_demo, write_json
from .bridge import fuse_evidence


def main():
    parser = argparse.ArgumentParser(description='智慧农业三模块第一阶段整合')
    commands = parser.add_subparsers(dest='command',required=True)
    demo = commands.add_parser('demo',help='Run the explicitly synthetic end-to-end fixture')
    demo.add_argument('--output',default='runs/demo')
    demo.add_argument('--date',default='2025-06-24')
    fusion = commands.add_parser('fuse',help='Review a JSON evidence request without executing a flight')
    fusion.add_argument('request')
    fusion.add_argument('--output',default='runs/fusion.json')
    args = parser.parse_args()
    try:
        if args.command == 'demo':
            result = run_demo(args.output,args.date)
            print(json.dumps(result['summary'],ensure_ascii=False,indent=2))
        else:
            payload = json.loads(Path(args.request).read_text(encoding='utf-8-sig'))
            result = fuse_evidence(payload)
            Path(args.output).parent.mkdir(parents=True,exist_ok=True)
            write_json(args.output,result)
            print(f'Saved {args.output}')
    except (ValueError,KeyError,TypeError) as exc:
        parser.exit(2,f'Input error: {exc}\n')


if __name__ == '__main__':
    main()
