import copy
import io
import json
from pathlib import Path
import numpy as np
import pytest
from fastapi.testclient import TestClient
from PIL import Image
from pyproj import Transformer
from agriculture.api import app
from agriculture.bridge import fuse_evidence, plan_requests, check_route
from agriculture.demo_scene import make_scene, scene_plots, SITE_ID
from agriculture.image.service import analyze_image
from agriculture.pipeline import run_demo
from agriculture.weather.service import weather_bundle
from agriculture.weather.weather import load_clean, indicators
from agriculture.weather.rules import fit_thresholds, screen


@pytest.fixture(scope='module')
def demo(tmp_path_factory):
    out = tmp_path_factory.mktemp('demo')
    result = run_demo(out)
    return result, json.loads((out/'fusion_request.json').read_text(encoding='utf-8'))


def test_end_to_end_computes_all_three_modules(demo):
    result, _ = demo
    assert result['summary']['accepted_images'] == 3
    assert result['summary']['quarantined_images'] == 0
    assert result['summary']['before_order'] == ['T001','T002','T003']
    assert set(result['summary']['after_order']) == {'T002','T003'}
    assert result['after']['status'] == 'simulation_validated'
    assert result['before']['validation']['passed']
    assert result['after']['trajectory']['metrics']['coverage_pct'] >= 99
    assert result['after']['trajectory']['coords']['crs'] == 'EPSG:32649'
    assert not result['summary']['flight_ready']
    assert result['fusion']['regional_candidates']
    assert result['image_observations'][0]['response']['data']['anomaly']['low_vigor_fraction'] == 0
    assert result['image_observations'][1]['response']['data']['anomaly']['low_vigor_fraction'] > .1


def test_uniform_image_float_statistics_stay_consistent():
    rgb = np.tile(np.array([40,140,40],dtype=np.uint8),(128,128,1))
    for stat in analyze_image(rgb)['data']['vegetation']['index_statistics'].values():
        assert stat['min'] <= stat['mean'] <= stat['max']


def test_coordinate_round_trip_and_site():
    scene = make_scene()
    transform = Transformer.from_crs('EPSG:4326',scene.meta['crs'],always_xy=True)
    for field,feature in zip(scene.fields,scene_plots(scene)['features']):
        ring = feature['geometry']['coordinates'][0][:-1]
        restored = np.array([transform.transform(*p) for p in ring])-scene.utm_origin
        np.testing.assert_allclose(restored,field.polygon,atol=1e-6)
        assert all(108.56 < p[0] < 108.62 and 25.58 < p[1] < 25.625 for p in ring)


@pytest.mark.parametrize('stamp',['2025-06-01T08:00:00+08:00','2025-06-25T08:00:00+08:00',
                                 '2025-06-24T08:00:00'])
def test_stale_future_or_naive_image_quarantined(demo,stamp):
    payload = copy.deepcopy(demo[1])
    for item in payload['image_observations']:
        item['metadata']['captured_at'] = stamp
    result = fuse_evidence(payload)
    assert len(result['quarantined_observations']) == 3
    assert result['inspection_requests'] == []


@pytest.mark.parametrize('field,value',[('demo_mode',False),('demo_mode','true'),
                                       ('site_id','yuanyang'),('as_of_date','2026-11-12')])
def test_invalid_context_rejected(demo,field,value):
    payload = copy.deepcopy(demo[1]); payload[field] = value
    with pytest.raises(ValueError):
        fuse_evidence(payload)


def test_regional_weather_without_local_evidence_does_not_assign_fields(demo):
    payload = copy.deepcopy(demo[1]); payload['image_observations'] = []
    result = fuse_evidence(payload)
    assert result['regional_candidates'] and not result['inspection_requests']
    assert plan_requests(make_scene(),result)['trajectory'] is None


def test_normal_latest_capture_clears_old_anomaly(demo):
    payload = copy.deepcopy(demo[1])
    normal = payload['image_observations'][0]['response']
    for item in list(payload['image_observations']):
        newer = copy.deepcopy(item)
        newer['metadata']['observation_id'] += '_new'
        newer['metadata']['captured_at'] = '2025-06-24T12:00:00+08:00'
        newer['response'] = normal
        payload['image_observations'].append(newer)
    assert fuse_evidence(payload)['inspection_requests'] == []


def test_unverified_plot_or_image_not_promoted(demo):
    payload = copy.deepcopy(demo[1])
    payload['plots']['features'][0]['properties']['crs_verified'] = False
    with pytest.raises(ValueError):
        fuse_evidence(payload)
    payload = copy.deepcopy(demo[1])
    payload['image_observations'][1]['metadata']['plot_association_verified'] = False
    result = fuse_evidence(payload)
    assert len(result['quarantined_observations']) == 1
    assert [t['plot_id'] for t in result['inspection_requests']] == ['T003']


@pytest.mark.parametrize('mutation',['id','scene','geometry','priority','duplicate'])
def test_route_adapter_rejects_unbound_tasks(demo,mutation):
    fusion = json.loads(json.dumps(demo[0]['fusion']))
    task = fusion['inspection_requests'][0]
    if mutation == 'id': task['plot_id'] = 'T999'
    if mutation == 'scene': task['scene_id'] = 'yuanyang'
    if mutation == 'geometry': task['geometry']['coordinates'][0][0][0] += .001
    if mutation == 'priority': task['priority'] = 'P9'
    if mutation == 'duplicate': fusion['inspection_requests'].append(copy.deepcopy(task))
    with pytest.raises(ValueError):
        plan_requests(make_scene(),fusion)


def test_full_route_validation_checks_capture_segments(demo):
    scene = make_scene()
    trajectory = copy.deepcopy(demo[0]['after']['trajectory'])
    point = next(w for w in trajectory['waypoints'] if w['action']=='capture')
    point['x'],point['y'] = 100.,100.
    assert check_route(scene,trajectory)['blocked_samples'] > 0
    trajectory['metrics']['battery_reserve_ok'] = False
    assert not check_route(scene,trajectory)['passed']


def test_upstream_collision_diagnostic_cannot_be_overridden(demo):
    trajectory = copy.deepcopy(demo[0]['after']['trajectory'])
    trajectory['metrics']['collision_count'] = 1
    assert not check_route(make_scene(),trajectory)['passed']


def test_original_scene_not_mutated_by_feedback(demo):
    scene = make_scene()
    plan_requests(scene,demo[0]['fusion'])
    assert all(f.risk==0 and f.priority==1 for f in scene.fields)


def test_same_plot_id_in_other_scene_is_quarantined(demo):
    payload = copy.deepcopy(demo[1])
    payload['image_observations'][1]['metadata']['scene_id'] = 'other_scene'
    result = fuse_evidence(payload)
    assert len(result['quarantined_observations']) == 1
    assert [t['plot_id'] for t in result['inspection_requests']] == ['T003']


def test_weather_recomputed_without_future_calibration():
    cfg,quality,thresholds,records = weather_bundle()
    assert quality['rows'] == 1826
    assert len(records) == 1826*5
    assert not quality['invalid_values']
    source = Path(__file__).resolve().parents[1]/'data/weather/weather_daily.csv'
    clean,_ = load_clean(source)
    features = indicators(clean,cfg)
    modified = features.copy()
    modified.loc[modified.date >= '2024-01-01','chirps_rain_3d_mm'] = 1e9
    import pandas as pd
    pd.testing.assert_frame_equal(fit_thresholds(modified,cfg),thresholds)
    changed = clean.copy()
    changed.loc[changed.date > '2025-06-24','nasa_rh_pct'] = 1
    replay = screen(indicators(changed,cfg),thresholds,cfg)
    assert [r for r in replay if r['date'] <= '2025-06-24'] == [r for r in records if r['date'] <= '2025-06-24']


def test_missing_weather_stays_unknown(tmp_path):
    cfg = weather_bundle()[0]
    source = Path(__file__).resolve().parents[1]/'data/weather/weather_daily.csv'
    clean,_ = load_clean(source)
    path = tmp_path/'gap.csv'
    clean.iloc[:40].drop(index=8).to_csv(path,index=False)
    edited,quality = load_clean(path)
    result = indicators(edited,cfg)
    assert quality['inserted_missing_dates']==['2021-01-09']
    assert np.isnan(result.loc[14,'chirps_rain_7d_mm'])


def test_api_image_weather_fusion_planning(demo):
    client = TestClient(app)
    assert client.get('/health').json()['data']['segmentation_available'] is False
    image = Image.new('RGB',(32,32),(40,140,40))
    buffer = io.BytesIO(); image.save(buffer,format='PNG')
    response = client.post('/image/analyze',files={'file':('中文.png',buffer.getvalue(),'image/png')})
    assert response.status_code==200
    assert response.json()['data']['anomaly']['low_vigor_fraction']==0
    assert client.post('/image/analyze',files={'file':('bad.png',b'bad','image/png')}).status_code==422
    assert client.post('/image/segment').status_code==503
    assert len(client.get('/weather/risk?as_of_date=2025-06-24').json()['data'])==5
    assert client.get('/weather/risk?as_of_date=2026-11-12').status_code==404
    assert client.get('/weather/risk?as_of_date=bad').status_code==422
    response = client.post('/integration/fuse',json=demo[1])
    assert response.status_code==200 and len(response.json()['data']['inspection_requests'])==2
    response = client.post('/planning/from-evidence',json=demo[1])
    assert response.status_code==200 and response.json()['data']['validation']['passed']
    assert client.post('/integration/fuse',json={'site_id':SITE_ID}).status_code==422
    assert client.post('/demo/run',json={'demo_mode':False}).status_code==422
    assert client.post('/demo/run',json={'demo_mode':'true'}).status_code==422


def test_demo_api_explicit_mode():
    result = TestClient(app).post('/demo/run',json={'demo_mode':True})
    assert result.status_code==200
    assert result.json()['data']['summary']['accepted_images']==3
    assert result.json()['data']['artifacts_persisted'] is False
