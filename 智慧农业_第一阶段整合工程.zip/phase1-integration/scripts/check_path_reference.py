"""Recompute both complete Yuanyang caches independently of Jiabang weather."""
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from agriculture.planning.simulator.scene import Scene
from agriculture.planning.planner.route import plan_mission
from agriculture.planning.simulator.inspect import inspect_mission
from agriculture.bridge import check_route


def main():
    out = ROOT/'validation'
    out.mkdir(exist_ok=True)
    original = json.loads((ROOT/'data/path_reference/metrics.json').read_text(encoding='utf-8'))
    rows = []
    for sid in ['scene_medium','scene_complex']:
        scene = Scene.load(sid,ROOT/'data/path_reference'/sid)
        for method in ['baseline','improved']:
            trajectory = plan_mission(scene,method)
            inspection = inspect_mission(trajectory,scene,generate_images=False)
            metrics = trajectory['metrics']
            metrics['coverage_pct'] = inspection['totals']['coverage_pct']
            reference = next(r for r in original if r['scene']==sid and r['method']==method)
            delta = {key:round(metrics[key]-float(reference[key]),6)
                     for key in ['path_length_m','energy_wh','coverage_pct']}
            rows.append({'scene':sid,'method':method,'metrics':metrics,
                         'delta_from_upstream':delta,
                         'full_route_validation':check_route(scene,trajectory)})
    (out/'path_reference.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps([{'scene':r['scene'],'method':r['method'],'delta':r['delta_from_upstream'],
                      'full_route_passed':r['full_route_validation']['passed']} for r in rows],indent=2))
    if any(abs(v)>.11 for r in rows for v in r['delta_from_upstream'].values()):
        raise SystemExit('Reference differences require review')


if __name__=='__main__':
    main()
