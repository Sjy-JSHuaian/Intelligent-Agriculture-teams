"""Optional report figure: pip install matplotlib, then run this script."""
import json
from pathlib import Path
import sys
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Polygon, Rectangle
from matplotlib.font_manager import FontProperties

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from agriculture.demo_scene import make_scene


def main():
    result = json.loads((ROOT/'runs/demo/result.json').read_text(encoding='utf-8'))
    scene = make_scene()
    font = Path('C:/Windows/Fonts/msyh.ttc')
    if font.exists():
        plt.rcParams['font.family'] = FontProperties(fname=str(font)).get_name()
    plt.rcParams['axes.unicode_minus'] = False
    fig, axes = plt.subplots(1,2,figsize=(12,6),layout='constrained')
    fig.patch.set_facecolor('#f5f7f4')
    titles = ['初始巡检：3个地块','证据融合后复查：2个地块']
    trajectories = [result['before']['trajectory'],result['after']['trajectory']]
    for ax,title,traj in zip(axes,titles,trajectories):
        ax.set_facecolor('#fbfcfa')
        for field in scene.fields:
            selected = field.field_id in traj['route']
            color = '#cde5c7' if field.field_id=='T001' else '#f3d7a5'
            ax.add_patch(Polygon(field.polygon,facecolor=color,edgecolor='#4c6854',alpha=1 if selected else .35))
            ax.text(*field.centroid,field.field_id,ha='center',va='center',fontsize=11,fontweight='bold')
        ax.add_patch(Rectangle((90,85),20,30,color='#4b5563'))
        xy = np.array([[w['x'],w['y']] for w in traj['waypoints']])
        ax.plot(xy[:,0],xy[:,1],color='#2b6485',lw=1.4,alpha=.9,zorder=2)
        ax.scatter(*scene.depot,s=80,marker='^',color='#c75640',zorder=5)
        ax.annotate('起降点',scene.depot,xytext=(7,-16),textcoords='offset points',fontsize=9)
        ax.set(xlim=(0,200),ylim=(0,200),xlabel='局部东向距离 / m',ylabel='局部北向距离 / m')
        ax.set_aspect('equal')
        ax.grid(alpha=.15)
        m = traj['metrics']
        ax.set_title(f"{title}\n航程 {m['path_length_m']:.1f} m · 能耗 {m['energy_wh']:.2f} Wh · 目标地块覆盖 {m['coverage_pct']:.0f}%",fontsize=11,pad=12)
    fig.suptitle('三模块协同联调：RGB异常候选 + 历史天气 → 复查任务 → 航线',fontsize=15,fontweight='bold')
    fig.supxlabel('全部地块、影像和地形为合成数据。前后任务集合不同，本图不用于比较算法优化率。',fontsize=10)
    out = ROOT/'validation/route_demo.png'
    fig.savefig(out,dpi=180)
    print(out)


if __name__=='__main__':
    main()
